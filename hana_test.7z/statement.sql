with t1 as (
    select
       "region" as "region",
       "country" as "country",
       SUM("eur_mnf") as "eur_mnf"
    from "SXGMDA"."gmda.monthly.cv::cv_ana_monthly" (placeholder."$$IP_CURR$$"=>'EUR', placeholder."$$IP_VERSION$$"=>'PROD') dm
    where "quarter_rel_id" = 0 AND "agg_type" = 'MONTH'
    group by "region", "country", "quarter_rel_id", "month_rel_id"
),

t2 as (
select distinct
    CAST("region" AS VARCHAR) as "region",
    CAST("country" AS VARCHAR) as "country",
    SUM("eur_mnf") OVER () as "eur_mnf/Total"
from t1
),

t7 as (
select
    'Total' as "Total",
    "region",
    "country"
from t2
)

select * from (
    select distinct
            "Total" as "NodeID",
            'root' as "ParentNodeID",
            IFNULL(null,' All') as "region",
            IFNULL(null,' All') as "country"
    from t7
    union all
    select distinct
            CONCAT(CONCAT(CONCAT(CONCAT("Total", '//'), IFNULL("region",'region')), '//'), IFNULL("country",'country')) as "NodeID",
            CONCAT(CONCAT("Total", '//'), IFNULL("region",'region')) as "ParentNodeID",
            IFNULL("region",' All') as "region",
            IFNULL("country",' All') as "country"
    from t7
)