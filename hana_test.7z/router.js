const fs = require('fs');
const path = require('path');
const express = require('express');
const router = express.Router();
const dao = require('./dao');
const { promisify } = require('util');
const hdbext = require('@sap/hdbext');
const xsenv = require('@sap/xsenv');

const https = require('https');
https.globalAgent.options.ca = xsenv.loadCertificates();





require('dotenv').config();
// console.log(process.env.VCAP_SERVICES);
// var services = xsenv.readServices();
// console.log(services);

const hanaMiddleware = require('./hana.middleware');

const secure = require('./passport/secure');



const statement = fs.readFileSync(path.resolve(__dirname, 'statement.sql'), 'utf8')

const createConnection = promisify(hdbext.createConnection);

router.get("/test", function(req, res) {
    res.type("application/json").status(200).send('test');				
});

router.get("/dmt", async function(req, res) {
    // const hanaOptionsEnv = xsenv.getServices({
    //     hana: {
    //         tag: 'hana',
    //     },
    // });

    const client = await createConnection({ ...hanaOptionsEnv.hana });
    const secondDAO = new dao(client);
    const statement = await secondDAO.preparePromisified(`select * from "dqt.db::repo.pt_query"`);
    const data = await secondDAO.statementExecPromisified(statement);
    res.type("application/json").status(200).send(data);				
});

// router.get("/query", async function(req, res, next) {
router.get("/query", hanaMiddleware, async function(req, res, next) {

    console.log('authInfo', req.authInfo);

	var connParams = {
		serverNode: "3.122.113.107:39015",
		uid: "DMT",
		pwd: "DmtPass123",
        CURRENTSCHEMA: "SXGMDA"
    };

    const hanaOptions = {
        ...connParams,
        'sessionVariable:XS_APPLICATIONUSER': 'eyJhbGciOiAiUlMyNTYiLCJ0eXAiOiAiSldUIn0.eyJqdGkiOiJmYmNhNDUyOTBjMWM0MzYzYmZhYmRkODY1NGFhMzY5MyIsImV4dF9hdHRyIjp7ImVuaGFuY2VyIjoiWFNVQUEifSwiZ2l2ZW5fbmFtZSI6IlNlcmdleSIsInhzLnVzZXIuYXR0cmlidXRlcyI6e30sImZhbWlseV9uYW1lIjoiWmhhcmtvIiwic3ViIjoiMTc0ODEzIiwic2NvcGUiOlsiRl9TTURDX0RNVC5DcmVhdGUiLCJGX1NNRENfRE1ULkVkaXQiLCJGX1NNRENfRE1ULkRpc3BsYXkiLCJvcGVuaWQiXSwiY2xpZW50X2lkIjoic2ItRl9TTURDX0RNVCIsImNpZCI6InNiLUZfU01EQ19ETVQiLCJhenAiOiJzYi1GX1NNRENfRE1UIiwiZ3JhbnRfdHlwZSI6InBhc3N3b3JkIiwidXNlcl9pZCI6IjE3NDgxMyIsIm9yaWdpbiI6InVhYSIsInVzZXJfbmFtZSI6IlNaSEFSS08iLCJlbWFpbCI6IlNlcmdleV9aaGFya29AZXBhbS5jb20iLCJhdXRoX3RpbWUiOjE1ODUwMjcxNzksInJldl9zaWciOiIyOTQ0OTI1NyIsImlhdCI6MTU4NTAyNzE4MCwiZXhwIjoxNTg1MDcwMzgwLCJpc3MiOiJodHRwOi8veHNhLTZhNmUzYzQwLWJkNTAtZWQ0YS05ZmMxLWFlNjgwMjNhMGFkYi9VQUEvb2F1dGgvdG9rZW4iLCJ6aWQiOiJ1YWEiLCJhdWQiOlsib3BlbmlkIiwic2ItRl9TTURDX0RNVCIsIkZfU01EQ19ETVQiXX0.VVq5-Y-Q3PmsxZqZ2zfW10jv2J0C7F6a8MDfuWW8X0bFsia5KIH055KmTOlnaweVJ2B5oihKgIsMVDB5rV3iEMNgAWI_rX_AQgXOa1iDJJ1F8DTIqXIB-aoSEOPk6Pim4QIKAVIniAzKzocGYWG45LI6UAtXcBzzWvwqbaupMoBeJuLiJufmWsCNNweYf9s4TOzdV-ym_qFrDuBrk4Gihx-6bIT96sZYUYXZloX-ayqdi6DBGvt5N2IPPYfC2wMK4RpT2A0YXQn08HCI_U5iyhyss4t4xDJOYfmbIULvLTPFszakedv_9MO-9D5Bsz1DJdZxVF2j6U4ERYfaTpreTA'
        ,
    };

    const hanaOptionsEnv = xsenv.getServices({
        hana: {
            tag: 'hana',
        },
    });

    let client;
    let secondDAO;
    let rawData;

    try {
        client = await createConnection({ ...hanaOptionsEnv.hana, ...hanaOptions });
        secondDAO = new dao(client);
        rawData = await secondDAO.execGeneratedQuery(statement);
        // console.log(await secondDAO.getSessionData());
    } catch (err) {
        next(err);
        throw new Error(`Error: ',`, err);
    }

    res.type("application/json").status(200).send(rawData);
});

module.exports = router;