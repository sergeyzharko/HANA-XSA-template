var port = process.env.PORT || 3000;
var express = require("express");
var app = express();
const router = require('./router');


// const hanaOptions = xsenv.getServices({
// 	hana: {
// 		tag: 'hana',
// 	},
// });

// const hanaMiddleware = hdbext.middleware(hanaOptions.hana);



app.use('/', router);


const passport = require('./passport');

app.use(passport);

// app.use('/', hanaMiddleware, childRouter);

app.use(function(err, req, res, _next) {
	let {
		message,
		description = '',
		stack,
		status = 500,
		addInfo = null,
	} = err;
	// set locals, only providing error in development
	res.locals.message = message;
	res.locals.error = req.app.get('env') === 'development' ? err : {};

	// add this line to include winston logging
	console.error(`${status} - ${message} - ${description ? description + ' - ' : ''}${req.originalUrl} - ${req.method} - ${req.ip}`);
	console.error(`${stack}`);

	// render the error page
	res.status(status).json({
		message,
		description,
		stack,
		addInfo,
	});
});

app.listen(port);

console.log("Server listening on port %d", port);