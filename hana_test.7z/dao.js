const HDBAbstractDAO = require('./HDBAbstractDAO');

module.exports = class extends HDBAbstractDAO {
	constructor(oDBClient) {
		super(oDBClient);
	}

	async execGeneratedQuery(query, params = []) {
		const statement = await this.preparePromisified(query);
		return await this.statementExecPromisified(statement, params);
	}

	async findConnectionById(connectionId) {
		const query = `
			SELECT
			"connection.string"
			FROM "${DB.TABLES.METADATA_CONNECTION}"
			WHERE "id" = ?`;

		const statement = await this.preparePromisified(query);
		const results = await this.statementExecPromisified(statement, [connectionId]);

		return {
			results,
		};
	}

	async getGrouping(projectId, entity, grouping) {
		const query = `
			SELECT "dqt.grouping::sf_getCondition"(?, ?, ?) as "grouping" FROM DUMMY`;

		const statement = await this.preparePromisified(query);
		const results = await this.statementExecPromisified(statement, [projectId, entity, grouping]);

		return {
			results,
		};
	}
};
